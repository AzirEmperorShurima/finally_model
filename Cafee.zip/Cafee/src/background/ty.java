/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package background;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author TRAN VAN TRI
 */
public class ty {
      private static final List<String> data = new ArrayList<>();

    public static List<String> getdata() {
        data.add("small");
        data.add("medium");
        data.add("big");
        return data;
    }

}
