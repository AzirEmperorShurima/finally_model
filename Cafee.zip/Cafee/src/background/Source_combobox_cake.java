/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package background;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author TRAN VAN TRI
 */
public class Source_combobox_cake {

    private static final List<String> data = new ArrayList<>();

    public static List<String> getdata() {
        data.add("small");
        data.add("big");
        data.add("normal");
        return data;
    }
}
