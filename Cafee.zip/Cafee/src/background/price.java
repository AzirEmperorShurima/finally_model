/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package background;

import java.awt.Color;
import java.awt.Font;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.PrintStream;
import java.util.List;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.BorderFactory;
import javax.swing.JOptionPane;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author TRAN VAN TRI
 */
public class price extends javax.swing.JFrame {

    /**
     * Creates new form price
     */
    private DefaultTableModel model;
    private String milktea1 = "milktea";
    private String cf = "coffee";
    private String ck = "cake";

    public price() {
        initComponents();
        setfomat();
        showdata1();
        
        

        try {
            Scanner sc = new Scanner(new FileReader("price.txt"));
            DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
            while (sc.hasNext()) {
                model.addRow(new Object[]{
                    sc.next(),
                    sc.next().replace('_', ' '),
                    sc.next()});
            }
            sc.close();
        } catch (Exception e) {

        }
    }
    


    private void setfomat() {
        this.setLocationRelativeTo(null);
        previous.setText(" Previous Page ");
        previous.setFont(new Font("Time New Roman", Font.BOLD, 15));
        previous.setForeground(Color.YELLOW);
        previous.setBackground(Color.black);
        setTitle(" Commodity Price Management ");
        getContentPane().setBackground(Color.black);
        jLabel1.setText("Item's Name :");
        jLabel1.setForeground(Color.WHITE);
        jLabel1.setFont(new Font("Time New Roman", Font.BOLD, 15));
        jLabel1.setVerticalAlignment(SwingConstants.CENTER);
        jLabel1.setHorizontalAlignment(SwingConstants.CENTER);
        jLabel2.setText("Price :");
        jLabel2.setForeground(Color.WHITE);
        jLabel2.setFont(new Font("Time New Roman", Font.BOLD, 15));
        jLabel3.setText(" Change Item's Price");
        jLabel3.setVerticalAlignment(SwingConstants.CENTER);
        jLabel3.setHorizontalAlignment(SwingConstants.CENTER);
        jLabel3.setBorder(BorderFactory.createLineBorder(Color.yellow,3));
        jLabel3.setFont(new Font("Time New Roman", Font.BOLD, 20));
        jLabel3.setBounds(200, 100, 300, 150);  
        jLabel3.setForeground(Color.YELLOW);
        jLabel3.setBackground(Color.blue);
        jLabel4.setText(" Type ");
        jLabel4.setForeground(Color.red);
        jLabel4.setFont(new Font("Time New Roman", Font.BOLD, 15));
        jLabel4.setBackground(Color.yellow);

        txtfind.setText("");
        txtfind.setForeground(Color.red);
        txtfind.setBackground(Color.white);
        txtfind.setFont(new Font("Time New Roman", Font.BOLD, 15));
        txtfind.setBorder(BorderFactory.createLineBorder(Color.yellow,2));
        delete.setBorder(BorderFactory.createLineBorder(Color.yellow,2));
        delete.setForeground(Color.yellow);
        delete.setBackground(Color.black);
        delete.setFont(new Font("Time New Roman", Font.BOLD, 15));
        update.setForeground(Color.yellow);
        update.setBackground(Color.black);
        update.setFont(new Font("Time New Roman", Font.BOLD, 15));
        reset.setForeground(Color.yellow);
        reset.setBackground(Color.black);
        reset.setBorder(BorderFactory.createLineBorder(Color.yellow,2));
        reset.setFont(new Font("Time New Roman", Font.BOLD, 15));
        name1.setText("");
        type.setBorder(BorderFactory.createLineBorder(Color.yellow,2));
        type.setFont(new Font("Time New Roman", Font.BOLD, 15));
        
        name1.setFont(new Font("Time New Roman", Font.BOLD, 15));
        name1.setBackground(Color.yellow);
        price1.setText("");
        price1.setBackground(Color.yellow);
        price1.setFont(new Font("Time New Roman", Font.BOLD, 15));
        addnew.setText("Add New ");
        addnew.setForeground(Color.red);
        addnew.setBorder(BorderFactory.createLineBorder(Color.red,2));
        addnew.setFont(new Font("Time New Roman", Font.BOLD, 15));
        save.setText(" Save ");
        save.setForeground(Color.yellow);
        save.setBackground(Color.black);
        save.setBorder(BorderFactory.createLineBorder(Color.yellow,2));
        save.setFont(new Font("Time New Roman", Font.BOLD, 15));
        find.setText(" Find ");
        find.setBorder(BorderFactory.createLineBorder(Color.yellow,2));
        find.setFont(new Font("Time New Roman", Font.BOLD, 15));
        find.setForeground(Color.yellow);
        find.setBackground(Color.black);
        jTable1.setOpaque(true);
        jTable1.setFont(new Font("Time New Roman", Font.BOLD, 15));
        jTable1.setFillsViewportHeight(true);
        jTable1.setForeground(Color.black);
        jTable1.setBackground(Color.YELLOW);
        jTable1.setBorder(BorderFactory.createLineBorder(Color.red,2));
        jTable1.getTableHeader().setForeground(Color.red);
        jTable1.getTableHeader().setOpaque(true);
        jTable1.getTableHeader().setFont(new Font("Time New Roman", Font.BOLD, 15));
        setdataBT.setBackground(Color.black);
        setdataBT.setForeground(Color.yellow);
        setdataBT.setBorder(BorderFactory.createLineBorder(Color.yellow,2));
        setdataBT.setFont(new Font("Time New Roman", Font.BOLD, 15));
        //   jTable1.getTableHeader().setBackground(Color.red);

    }

    private void showdata1() {
        type.addItem("milktea");
        type.addItem("coffee");
        type.addItem("cake");
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        name1 = new javax.swing.JTextField();
        price1 = new javax.swing.JTextField();
        addnew = new javax.swing.JButton();
        save = new javax.swing.JButton();
        reset = new javax.swing.JButton();
        find = new javax.swing.JButton();
        txtfind = new javax.swing.JTextField();
        delete = new javax.swing.JButton();
        update = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        type = new javax.swing.JComboBox<>();
        previous = new javax.swing.JButton();
        setdataBT = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Item's Name", "Price", "Special"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        jLabel1.setText("jLabel1");

        jLabel2.setText("jLabel2");

        jLabel3.setText("jLabel3");

        name1.setText("jTextField1");
        name1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                name1ActionPerformed(evt);
            }
        });

        price1.setText("jTextField2");

        addnew.setText("addnew");
        addnew.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addnewActionPerformed(evt);
            }
        });

        save.setText("save");
        save.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveActionPerformed(evt);
            }
        });

        reset.setText("Reset");
        reset.setToolTipText("");
        reset.setBorder(null);
        reset.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                resetActionPerformed(evt);
            }
        });

        find.setText("find_name");
        find.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                findActionPerformed(evt);
            }
        });

        txtfind.setText("jTextField1");

        delete.setText("Delete");
        delete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteActionPerformed(evt);
            }
        });

        update.setText("Update");
        update.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateActionPerformed(evt);
            }
        });

        jLabel4.setText("jLabel4");

        type.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                typeActionPerformed(evt);
            }
        });

        previous.setText("jButton1");
        previous.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                previousActionPerformed(evt);
            }
        });

        setdataBT.setText("Reset Data");
        setdataBT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                setdataBTActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(80, 80, 80)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(name1, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(0, 0, Short.MAX_VALUE)
                                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(30, 30, 30)
                                        .addComponent(type, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(18, 18, Short.MAX_VALUE)
                                        .addComponent(price1, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                        .addGap(27, 27, 27)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(addnew)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(delete, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(setdataBT))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(save)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(update))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(reset, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(find)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtfind, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addComponent(previous)
                        .addGap(79, 79, 79)
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 323, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(90, 90, 90))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 539, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(reset, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(find)
                            .addComponent(txtfind, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(25, 25, 25)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(delete, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(setdataBT))
                            .addComponent(addnew, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(previous)
                        .addGap(10, 10, 10)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(name1))
                        .addGap(20, 20, 20)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(price1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(24, 24, 24)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(type, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(save)
                            .addComponent(update))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 33, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 275, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void addnewActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addnewActionPerformed
        DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
        model.addRow(new Object[]{
            name1.getText(),
            price1.getText(),
            type.getSelectedItem()

        }); // TODO add your handling code here:
    }//GEN-LAST:event_addnewActionPerformed

    private void saveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveActionPerformed
        DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
        for (int i = 0; i < model.getRowCount(); i++) {
            try {
                PrintStream pw = new PrintStream("price.txt");
                PrintStream pp = new PrintStream("milktea.txt");
                PrintStream pr = new PrintStream("cfe.txt");
                PrintStream pa = new PrintStream("cakes.txt");
                for (i = 0; i < model.getRowCount(); i++) {
                    String checkk = (String) model.getValueAt(i, 2);
                    String check = checkk.trim();
                    pw.println(
                            model.getValueAt(i, 0) + "\t"
                            + (model.getValueAt(i, 1) + "").replace(' ', '_') + "  "
                            + model.getValueAt(i, 2)
                    );
                    if (check.equalsIgnoreCase(milktea1)) {
                        pp.println(
                                model.getValueAt(i, 0) + "\t"
                                + (model.getValueAt(i, 1) + "").replace(' ', '_')
                        );

                    } else if (check.equalsIgnoreCase(cf)) {
                        pr.println(
                                model.getValueAt(i, 0) + "\t"
                                + (model.getValueAt(i, 1) + "").replace(' ', '_')
                        );
                    } else if (check.equalsIgnoreCase(ck)) {
                        pa.println(
                                model.getValueAt(i, 0) + "\t"
                                + (model.getValueAt(i, 1) + "").replace(' ', '_')
                        );
                    }
                }
                JOptionPane.showMessageDialog(null, "done");
                
                pw.close();
                pp.close();
                pr.close();
                pa.close();
            } catch (Exception e) {
            }
        }
    }//GEN-LAST:event_saveActionPerformed

    private void name1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_name1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_name1ActionPerformed

    private void resetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_resetActionPerformed
        // TODO add your handling code here:
        name1.setText("");
        price1.setText("");
        txtfind.setText("");
    }//GEN-LAST:event_resetActionPerformed

    private void findActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_findActionPerformed
        // TODO add your handling code here:
        boolean check = false;
        DefaultTableModel model1 = (DefaultTableModel) jTable1.getModel();
        jTable1.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        int i = model1.getRowCount();
        for (int j = 0; j < i; j++) {
            if (txtfind.getText().equals(model1.getValueAt(j, 0))) {
                jTable1.setRowSelectionInterval(j, j);
                name1.setText((String) model1.getValueAt(j, 0));
                price1.setText((String) model1.getValueAt(j, 1));

            }
        }
    }//GEN-LAST:event_findActionPerformed

    private void deleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteActionPerformed
        // TODO add your handling code here:
        DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
        int i_row = jTable1.getSelectedRow();
        int luaChon = JOptionPane.showConfirmDialog(this, "Bạn có chắn chắn xóa dòng đã chọn?");
        if (luaChon == JOptionPane.YES_OPTION) {

            model.removeRow(i_row);
        }

    }//GEN-LAST:event_deleteActionPerformed

    private void updateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateActionPerformed
        // TODO add your handling code here:
        DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
        int i = jTable1.getSelectedRow();
        if (name1.getText() != model.getValueAt(i, 0) && name1.getText().isEmpty() == false) {
            model.setValueAt(name1.getText(), i, 0);
        }
        if (price1.getText() != model.getValueAt(i, 1) && price1.getText().isEmpty() == false) {
            model.setValueAt(price1.getText(), i, 1);
        }
        model.setValueAt(type.getSelectedItem(), i, 2);

    }//GEN-LAST:event_updateActionPerformed

    private void previousActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_previousActionPerformed
        // TODO add your handling code here:
        admin ad = new admin();
        ad.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_previousActionPerformed

    private void setdataBTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_setdataBTActionPerformed
        // TODO add your handling code here:
         DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
        try {
            int choice = JOptionPane.showConfirmDialog(null, "Are your want to reset data!");
            if(choice==JOptionPane.YES_OPTION){
                 PrintStream ps = new PrintStream("price.txt");
                 ps.print("");  
                 JOptionPane.showMessageDialog(null, "Successful");
                 dispose();
                 price ts = new price();
                 ts.setVisible(true);
//                 if(ts.equals(WindowEvent.WINDOW_CLOSED)){
//                    admin ad = new admin();
//                    ts.dispose();
//                 }
            }
            
        } catch (FileNotFoundException ex) {
            Logger.getLogger(price.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_setdataBTActionPerformed

    private void typeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_typeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_typeActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(price.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(price.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(price.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(price.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new price().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton addnew;
    private javax.swing.JButton delete;
    private javax.swing.JButton find;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField name1;
    private javax.swing.JButton previous;
    private javax.swing.JTextField price1;
    private javax.swing.JButton reset;
    private javax.swing.JButton save;
    private javax.swing.JButton setdataBT;
    private javax.swing.JTextField txtfind;
    private javax.swing.JComboBox<String> type;
    private javax.swing.JButton update;
    // End of variables declaration//GEN-END:variables
}
