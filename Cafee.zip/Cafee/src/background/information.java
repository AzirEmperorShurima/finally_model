package background;

import java.awt.Color;
import java.awt.Font;
import java.io.FileReader;
import java.io.PrintStream;
import java.util.Scanner;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.ListSelectionModel;
import javax.swing.UIManager;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;

/**
 *
 * @author TRAN VAN TRI
 */
public class information extends javax.swing.JFrame {

    //DefaultTableModel model;
    /**
     * Creates new form information
     */
    public information() {

        initComponents();
        fomat();
        
        // this.setLocationRelativeTo(null);
        //   list = new ArrayList<>();
        //  model = (DefaultTableModel) jTable1.getModel();
        jLabel2.setText("User Name :");
        jLabel3.setText(" Password :");
        jLabel4.setText(" Status : ");
        try {
            Scanner sc = new Scanner(new FileReader("usersource.txt"));
            DefaultTableModel model = (DefaultTableModel) inftable.getModel();
            //Ho tro them dong vao Table tren giao dien
            while (sc.hasNext()) {
                model.addRow(new Object[]{
                    sc.next(), //Ma
                    sc.next().replace('_', ' '), //Ten
                    sc.next()//Gia
                });
            }
            sc.close();
        } catch (Exception e) {

        }
    }

    private void fomat() {
        statusComboboxTF.addItem("admin");
        statusComboboxTF.addItem("user");
        statusComboboxTF.addItem("lock");
        this.setLocationRelativeTo(null);
        setTitle(" Iformation of Emplyee ");
        name.setText("");
        name.setBorder(BorderFactory.createLineBorder(Color.RED,3));
        pass.setText("");
        pass.setBorder(BorderFactory.createLineBorder(Color.RED,3));
        name.setFont(new Font("Time New Roman", Font.BOLD, 17));
        pass.setFont(new Font("Time New Roman", Font.BOLD, 17));
        statusComboboxTF.setFont(new Font("Time New Roman", Font.BOLD, 15));
        statusComboboxTF.setBorder(BorderFactory.createLineBorder(Color.RED,3));
        name.setForeground(Color.YELLOW);
        name.setBackground(Color.black);
        pass.setForeground(Color.YELLOW);
        pass.setBackground(Color.black);
        statusComboboxTF.setForeground(Color.YELLOW);
        find.setIcon(new ImageIcon(getClass().getResource("/background/Icon/find.png")));
        find.setText("FIND");
        find.setFont(new Font("Time New Roman", Font.BOLD, 15));
        find.setForeground(Color.black);
        findinput.setForeground(Color.black);
        findinput.setText("");
        findinput.setFont(new Font("Time New Roman", Font.BOLD, 15));

        jLabel1.setBackground(Color.pink);
        getContentPane().setBackground(Color.WHITE);
        addnew.setText("Add New ");
        addnew.setForeground(Color.ORANGE);
        addnew.setFont(new java.awt.Font("ime New Roman", 0, 20));
        addnew.setBackground(Color.BLACK);
        save.setText(" Save ");
        save.setFont(new java.awt.Font("ime New Roman", 0, 20));
        save.setForeground(Color.yellow);
        save.setBounds(100, 50, 50, 100);
        save.setBackground(Color.BLACK);
        resetBT.setText("Reset Box");
        resetBT.setBackground(Color.BLACK);
        resetBT.setFont(new java.awt.Font("Time New Roman", 0, 15));
        resetBT.setForeground(Color.red);
        resetBT.setBounds(100, 50, 50, 100);
        update.setText(" Update ");
        update.setBackground(Color.BLACK);
        update.setForeground(Color.red);
        update.setFont(new Font("Time New Roman", 0, 20));
        
        delete.setForeground(Color.red);
        delete.setBackground(Color.BLACK);
        delete.setFont(new Font("ime New Roman", 0, 20));
        resetBT.setFont(new Font("ime New Roman", 0, 15));
        resetBT.setForeground(Color.red);
        resetBT.setBackground(Color.BLACK);
        
        jLabel2.setText("Name ");
        jLabel2.setBorder(BorderFactory.createLineBorder(Color.red,3));
        jLabel2.setFont(new java.awt.Font("", Font.BOLD, 15));
        jLabel2.setForeground(Color.red);
        jLabel3.setText("Pass ");
        jLabel3.setBorder(BorderFactory.createLineBorder(Color.red,3));
        jLabel3.setFont(new java.awt.Font("", Font.BOLD, 15));
        jLabel3.setForeground(Color.red);
        jLabel4.setText("Status ");
        jLabel4.setBorder(BorderFactory.createLineBorder(Color.red,3));
        jLabel4.setFont(new java.awt.Font("", Font.BOLD, 15));
        jLabel4.setForeground(Color.red);
      
        delete.setText(" Delete ");
        inftable.setForeground(Color.ORANGE);   
        inftable.setFillsViewportHeight(true);
        inftable.setOpaque(true );
        inftable.setBackground(Color.black);
        inftable.getTableHeader().setOpaque(false);
        inftable.getTableHeader().setBackground(Color.blue);
        JTableHeader header = inftable.getTableHeader();
        header.setBackground(Color.red);
        inftable.getTableHeader().setBorder(BorderFactory.createLineBorder(Color.RED,3));
        inftable.getTableHeader().setForeground(Color.yellow);
        inftable.setFont(new Font("Time New Roman ", Font.BOLD, 17));
        inftable.getTableHeader().setFont(new Font("Time New Roman", Font.BOLD, 20));
        inftable.setShowHorizontalLines(true);
        inftable.setShowVerticalLines(true);
        inftable.setGridColor(Color.red);
        inftable.setBorder(BorderFactory.createLineBorder(Color.RED,3));
        pre.setText(" Previous Page ");
        pre.setFont(new java.awt.Font("", Font.BOLD, 15));;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        name = new javax.swing.JTextField();
        pass = new javax.swing.JTextField();
        addnew = new javax.swing.JButton();
        resetBT = new javax.swing.JButton();
        save = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        inftable = new javax.swing.JTable();
        delete = new javax.swing.JButton();
        update = new javax.swing.JButton();
        find = new javax.swing.JButton();
        findinput = new javax.swing.JTextField();
        pre = new javax.swing.JButton();
        statusComboboxTF = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Segoe UI Black", 0, 24)); // NOI18N
        jLabel1.setText("The Informations Of All Users");

        jLabel3.setText("jLabel3");

        jLabel4.setText("jLabel4");

        name.setText("name");
        name.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nameActionPerformed(evt);
            }
        });

        pass.setText("pass");

        addnew.setText("add new");
        addnew.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addnewActionPerformed(evt);
            }
        });

        resetBT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                resetBTActionPerformed(evt);
            }
        });

        save.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveActionPerformed(evt);
            }
        });

        inftable.setBackground(new java.awt.Color(213, 206, 211));
        inftable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "The Name", "Password", "Status"
            }
        ));
        jScrollPane1.setViewportView(inftable);

        delete.setText("jButton1");
        delete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteActionPerformed(evt);
            }
        });

        update.setText("jButton1");
        update.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateActionPerformed(evt);
            }
        });

        find.setText("jButton1");
        find.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                findActionPerformed(evt);
            }
        });

        findinput.setText("findinput");

        pre.setText("jButton1");
        pre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                preActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(51, 51, 51)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(pre)
                        .addGap(75, 75, 75)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 383, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(112, 112, 112)
                        .addComponent(findinput, javax.swing.GroupLayout.PREFERRED_SIZE, 244, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(find)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, 107, Short.MAX_VALUE)
                                    .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(pass, javax.swing.GroupLayout.DEFAULT_SIZE, 283, Short.MAX_VALUE)
                                    .addComponent(name, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(statusComboboxTF, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addComponent(update)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addComponent(resetBT, javax.swing.GroupLayout.DEFAULT_SIZE, 117, Short.MAX_VALUE)
                                .addGap(18, 18, 18)
                                .addComponent(delete)
                                .addGap(26, 26, 26)
                                .addComponent(addnew)
                                .addGap(15, 15, 15)
                                .addComponent(save, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(77, 77, 77)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 683, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(276, 276, 276))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(pre)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel1)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(findinput, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(find)))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 366, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(86, 86, 86)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(name, javax.swing.GroupLayout.DEFAULT_SIZE, 38, Short.MAX_VALUE)
                                    .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 16, Short.MAX_VALUE)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(pass, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(35, 35, 35)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(statusComboboxTF, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(83, 83, 83)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(addnew)
                                        .addComponent(delete))
                                    .addComponent(save, javax.swing.GroupLayout.DEFAULT_SIZE, 35, Short.MAX_VALUE)
                                    .addComponent(resetBT, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addGap(18, 18, 18)
                                .addComponent(update)
                                .addGap(90, 90, 90))))))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void addnewActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addnewActionPerformed
        DefaultTableModel model = (DefaultTableModel) inftable.getModel();
        int i = model.getRowCount();
        boolean check1 = true;
        for (int j = 0; j < i; j++) {
            if (name.getText().equals(model.getValueAt(j, 0))) {
                check1 = false;
                break;
            }
        }
        if (pass.getText().length() > 5 && check1) {

            model.addRow(new Object[]{
                name.getText(),
                pass.getText(),
                statusComboboxTF.getSelectedItem()
            });
        } else if (check1 == false && pass.getText().length() < 5) {
            JOptionPane.showMessageDialog(null, "You Must Check Name and Password must longger 5 ");
        } else if (pass.getText().length() < 5) {
            JOptionPane.showMessageDialog(null, "Password must be longer 5 ");
        } else {
            JOptionPane.showMessageDialog(null, "You Must Check Name Again");
        }
        /* employee e = new employee();
       e.setname(name.getText());
       e.setpass(pass.getText());
       e.setstatus(status.getText());
       list.add(e); // them vao danh sach SV
         */// showResult();
    }//GEN-LAST:event_addnewActionPerformed

    private void nameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_nameActionPerformed

    private void resetBTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_resetBTActionPerformed
        name.setText("");
        pass.setText("");
        statusComboboxTF.setSelectedIndex(0);
        findinput.setText("");
    }//GEN-LAST:event_resetBTActionPerformed

    private void saveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveActionPerformed
        try {
            PrintStream pw = new PrintStream("usersource.txt");
            DefaultTableModel model = (DefaultTableModel) inftable.getModel();
            for (int i = 0; i < model.getRowCount(); i++) {
                pw.println(
                        model.getValueAt(i, 0) + "  "
                        + (model.getValueAt(i, 1) + "").replace(' ', '_') + "\t"
                        + model.getValueAt(i, 2)
                );
            }
            pw.close();
            JOptionPane.showMessageDialog(null, "Lưu dữ liệu thành công!!!!!!!");
        } catch (Exception e) {

        }        // TODO add your handling code here:
    }//GEN-LAST:event_saveActionPerformed

    private void deleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteActionPerformed
        DefaultTableModel model = (DefaultTableModel) inftable.getModel();
        int i_row = inftable.getSelectedRow();
        int luaChon = JOptionPane.showConfirmDialog(this, "Bạn có chắn chắn xóa dòng đã chọn?");
        if (luaChon == JOptionPane.YES_OPTION) {

            model.removeRow(i_row);
        }
    }//GEN-LAST:event_deleteActionPerformed

    private void updateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateActionPerformed
        DefaultTableModel model = (DefaultTableModel) inftable.getModel();
        int i = inftable.getSelectedRow();
        if (name.getText() != model.getValueAt(i, 0) && name.getText().isEmpty() == false) {
            model.setValueAt(name.getText(), i, 0);
        }
        if (pass.getText() != model.getValueAt(i, 1) && pass.getText().isEmpty() == false) {
            model.setValueAt(pass.getText(), i, 1);
        }
        if (statusComboboxTF.getSelectedItem()!= model.getValueAt(i, 2) ) {
            model.setValueAt(statusComboboxTF.getSelectedItem(), i, 2);
        }
    }//GEN-LAST:event_updateActionPerformed

    private void findActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_findActionPerformed
        // TODO add your handling code here:
        boolean check = false;
        DefaultTableModel model = (DefaultTableModel) inftable.getModel();
        inftable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        int i = model.getRowCount();

        for (int j = 0; j < i; j++) {

            if (findinput.getText().equals(model.getValueAt(j, 0))) {
                inftable.setRowSelectionInterval(j, j);
                name.setText((String) model.getValueAt(j, 0));
                pass.setText((String) model.getValueAt(j, 1));
                statusComboboxTF.setSelectedItem((String) model.getValueAt(j, 2));
                check = true;
            }
        }
        if (check == false) {
            findinput.setText("");
            JOptionPane.showMessageDialog(null, "Can't Find Out This Information");
        }

    }//GEN-LAST:event_findActionPerformed

    private void preActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_preActionPerformed
        // TODO add your handling code here:

        admin ad = new admin();
        ad.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_preActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(information.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(information.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(information.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(information.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new information().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton addnew;
    private javax.swing.JButton delete;
    private javax.swing.JButton find;
    private javax.swing.JTextField findinput;
    private javax.swing.JTable inftable;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField name;
    private javax.swing.JTextField pass;
    private javax.swing.JButton pre;
    private javax.swing.JButton resetBT;
    private javax.swing.JButton save;
    private javax.swing.JComboBox<String> statusComboboxTF;
    private javax.swing.JButton update;
    // End of variables declaration//GEN-END:variables

    private void clear(JComboBox<String> status) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

}
