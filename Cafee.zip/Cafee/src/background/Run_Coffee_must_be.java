package background;

/**
 *
 * @author TRAN VAN TRI
 */

public class Run_Coffee_must_be {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        login LOGIN = new login();
        LOGIN.setVisible(true);

    }

}
