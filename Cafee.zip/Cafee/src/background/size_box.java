package background;

import java.util.List;
import java.util.ArrayList;

/**
 *
 * @author TRAN VAN TRI
 */
public class size_box {

    private static final List<String> data = new ArrayList<>();

    public static List<String> getdata() {
        data.add("small");
        data.add("big");
        data.add("normal");
        return data;
    }

}
